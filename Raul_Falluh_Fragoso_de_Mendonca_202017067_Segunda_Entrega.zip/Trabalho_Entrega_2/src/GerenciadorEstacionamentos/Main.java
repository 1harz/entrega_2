package GerenciadorEstacionamentos;

import javax.swing.JOptionPane;

public class Main 
{

	public static void main(String[] args) 
	{
		boolean novoAcesso;
		boolean novoEstacionamento;
		boolean novoEvento;
		boolean achaPlaca;
		int i = 0;
		int j = 0;
		int m = 0;
		int numVagas[] = new int[999];
		double valorFracao[] = new double[999];
		double valorHoraCheia[] = new double[999];
		double valorDiariaDiurna[] = new double[999];
		double valorPorcentagemNoturna[] = new double[999];
		String placa[] = new String[999];
		String nomeEstacionamento[] = new String[999];
		String nomeEvento[] = new String[999];
		int escolhaMenu;
		int diaEvento[] = new int[999];
		int mesEvento[] = new int[999];
		int anoEvento[] = new int[999];
		int horaInicioEvento[] = new int[999];
		int minInicioEvento[] = new int[999];
		int horaFinalEvento[] = new int[999];
		int minFinalEvento[] = new int[999];
		int opcaoPesquisa;
		String pesquisaPlaca;
		String pesquisaEstacionamento;
		String pesquisaEvento;
		
		do {
			System.out.println("----------\n");
			System.out.println("Digite qual funcao deseja acessar:\n");
			System.out.println("----------\n");
			System.out.println("(1) Criar um novo Acesso.\n");
			System.out.println("(2) Criar um novo Estacionamento.\n");
			System.out.println("(3) Criar um novo Evento.\n");
			System.out.println("(4) Pesquisar um Registro ja existente.\n");
			System.out.println("(5) Sair do Programa.\n");
			
			
			System.out.println("----------\n");
			escolhaMenu = Integer.parseInt(JOptionPane.showInputDialog("Digite a opcao desejada: \n"));
				switch(escolhaMenu) 
				{
					case 1: //Acesso
					{
							do 
							{
								int opcao = JOptionPane.showConfirmDialog(null, "Deseja Cadastrar Um Novo Acesso?");
								if(opcao == JOptionPane.YES_OPTION) 
								{
									i = i + 1;
									novoAcesso = true;
									placa[i-1] = JOptionPane.showInputDialog("Digite abaixo a placa do Veiculo:\n");
								}
								else 
								{
									novoAcesso = false;	
								}
							} while(novoAcesso);
							
					 }
						break;
					case 2: //Estacionamento
					{
						do 
						{
							int opcao = JOptionPane.showConfirmDialog(null, "Deseja Cadastrar Um Novo Estacionamento?\n");
							if(opcao == JOptionPane.YES_OPTION) 
							{
								j = j + 1;
								novoEstacionamento = true;
								nomeEstacionamento[j-1] = JOptionPane.showInputDialog("Digite abaixo o nome do Estacionamento:\n");
								numVagas[j-1] = Integer.parseInt(JOptionPane.showInputDialog("Digite abaixo o numero  de vagas do Estacionamento:\n"));
								valorFracao[j-1] = Double.parseDouble(JOptionPane.showInputDialog("Digite abaixo o valor da fracao de 15 minutos do estacionamento:\n"));
								valorHoraCheia[j-1] = Double.parseDouble(JOptionPane.showInputDialog("Digite abaixo o valor da hora cheia do estacionamento:\n"));
								valorDiariaDiurna[j-1] = Double.parseDouble(JOptionPane.showInputDialog("Digite abaixo o valor da diaria diurna do estacionamento:\n"));
								valorPorcentagemNoturna[j-1] = Double.parseDouble(JOptionPane.showInputDialog("Digite abaixo a porcentagem(%) da diaria noturna do estacionamento:\n"));
							}
							else 
							{
								novoEstacionamento = false;	
							}
						} while(novoEstacionamento);
					}
					break;
					case 3: //Evento
					{
						do 
						{
							int opcao = JOptionPane.showConfirmDialog(null, "Deseja Cadastrar Um Novo Evento?\n");
							if(opcao == JOptionPane.YES_OPTION) 
							{
								m = m + 1;
								novoEvento = true;
								nomeEvento[m-1] = JOptionPane.showInputDialog("Digite abaixo o nome do Evento:\n");
								diaEvento[m-1] = Integer.parseInt(JOptionPane.showInputDialog("Digite abaixo o dia do Evento:\n"));
								mesEvento[m-1] = Integer.parseInt(JOptionPane.showInputDialog("Digite abaixo o mes do Evento:\n"));
								anoEvento[m-1] = Integer.parseInt(JOptionPane.showInputDialog("Digite abaixo o ano do Evento:\n"));
								horaInicioEvento[m-1] = Integer.parseInt(JOptionPane.showInputDialog("Digite abaixo a hora de inicio do Evento:\n"));
								minInicioEvento[m-1] = Integer.parseInt(JOptionPane.showInputDialog("Digite abaixo os minutos relativos a hora de inico do Evento:\n"));
								horaFinalEvento[m-1] = Integer.parseInt(JOptionPane.showInputDialog("Digite abaixo a hora de fim do Evento:\n"));
								minFinalEvento[m-1] = Integer.parseInt(JOptionPane.showInputDialog("Digite abaixo os minutos relativos a hora de finalizacao do Evento:\n"));
								
							}
							else 
							{
								novoEvento = false;	
							}
						} while(novoEvento);
					}
					case 4: //Pesquisa
					{
						System.out.println("(1) Pesquisar um Acesso a partir da Placa do Veiculo.\n");
						System.out.println("(2) Pesquisar um Estacionamento a partir do nome do estacionamento.\n");
						System.out.println("(3) Pesquisar um Evento a partir do nome do evento.\n");
						System.out.println("(4) Sair do modo de pesquisa.\n");
						opcaoPesquisa = Integer.parseInt(JOptionPane.showInputDialog("Digite a opcao desejada: \n"));
						switch(opcaoPesquisa) 
						{
							case 1:
							{
								pesquisaPlaca = JOptionPane.showInputDialog("Digite abaixo a placa do veiculo a ser pesquisado:\n");
								for(int n = 0; n < 999; n++) 
								{
									if(pesquisaPlaca.equals(placa[n]))
									{
										achaPlaca = true;
									}else 
									{
										achaPlaca = false;
									}
								}
								if(achaPlaca = true) 
								{
									System.out.println("Veiculo de placa " + pesquisaPlaca + " foi encontrado no sistema.\n");
								}else 
								{
									System.out.println("Veiculo de placa " + pesquisaPlaca + " nao foi encontrado no sistema.\n");
								}
							}
								break;
							case 2:
							{
								pesquisaEstacionamento = JOptionPane.showInputDialog("Digite abaixo o nome do Estacionamento a ser pesquisado:\n");
							}
								break;
							case 3:
							{
								pesquisaEvento = JOptionPane.showInputDialog("Digite abaixo o nome do evento a ser pesquisado:\n");
							}
								break;
							case 4:
							{
								System.out.println("Saindo do modo de pesquisa...\n");
							}
								break;
							default:
							{
								System.out.println("Opcao invalida, insira novamente.\n");
							}
								break;
						}
					}
						
						break;

					case 5: //Fechar o Programa
					{
						System.out.println("Fechando o Programa...\n");
						System.out.println("----------\n");
					}
						break;
					default: //Caso opcao invalida
						System.out.println("Opcao invalida, insira novamente.");
						break;
				}
			
		} while(escolhaMenu != 5);
	}
}
